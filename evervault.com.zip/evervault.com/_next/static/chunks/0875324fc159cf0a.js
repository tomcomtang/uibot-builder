__turbopack_load_page_chunks__("/contact", [
  "static/chunks/2a6d52ce9fb7f07b.js",
  "static/chunks/8ebd23f609a898d0.js",
  "static/chunks/3bb8a2299a36c3c7.js",
  "static/chunks/334538a8c4ef4460.js",
  "static/chunks/c3c082daaabceba7.js",
  "static/chunks/1ea26b574449753a.js",
  "static/chunks/68354345f82857bd.js",
  "static/chunks/49b97cf077730aa0.js",
  "static/chunks/6dfbca0234f0a2ee.js",
  "static/chunks/0a667f32147c2f23.js",
  "static/chunks/c9aa126dd6e5156b.js",
  "static/chunks/8dfd1af5812db7f7.css",
  "static/chunks/2c783d819a16cae5.css",
  "static/chunks/turbopack-2a88428290fe4af5.js"
])
